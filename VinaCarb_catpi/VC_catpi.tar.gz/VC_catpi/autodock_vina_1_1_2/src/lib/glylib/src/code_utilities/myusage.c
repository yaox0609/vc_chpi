// Function written by B. Lachele Foley, 2007

// prints usage message and exits
#include <mylib.h>
//#include "../inc/mylib.h"

void myusage(const char *usg){ 
	printf("Usage:\n%s\n",usg); 
        exit(1);
}

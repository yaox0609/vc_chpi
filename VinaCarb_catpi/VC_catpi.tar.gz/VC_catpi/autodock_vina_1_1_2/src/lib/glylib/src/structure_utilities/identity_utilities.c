/** \file identity_utilities.c
*   Purpose:  Functions for figuring out what things are
*   Begin 20110428 BLFoley
*
*/
#include <mylib.h>
#include <molecules.h>

void set_atom_element_best_guess(atom *a)
{
mywhine("the function set_atom_element_best_guess has not been written yet");
return;
}

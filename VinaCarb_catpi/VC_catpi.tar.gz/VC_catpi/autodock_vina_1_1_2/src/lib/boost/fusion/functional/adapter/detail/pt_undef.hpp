/*=============================================================================
    Copyright (c) 2006-2007 Tobias Schwinger
  
    Use modification and distribution are subject to the Boost Software 
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
==============================================================================*/

// No include guard - this file is included multiple times intentionally.

#undef PT0
#undef PT1
#undef PT2
#undef PT3
#undef PT4
#undef PT5
#undef PT6
#undef PT7
#undef PT8
#undef PT9
#undef PT10
#undef PT11

